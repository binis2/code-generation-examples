@ECHO OFF
set JAVA_HOME=C:\Program Files\Java\jdk-18.0.1.1
cls
cd code-generation-core
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-spring
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-annotation
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-plugin
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-test
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-validation
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-projection
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-jackson
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-spring-configuration
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-hibernate
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-redis
call deploy.bat
cd..
if %errorlevel% neq 0 exit /b %errorlevel%

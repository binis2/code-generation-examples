@ECHO OFF
cd code-generation-core
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-annotation
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%



 
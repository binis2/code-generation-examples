@ECHO OFF
cd code-generation-core
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-spring
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-annotation
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-plugin
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-test
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-validation
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-projection
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-jackson
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-spring-configuration
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-hibernate
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%
cd code-generation-redis
call mvn clean install -Dmaven.test.skip=true
cd..
if %errorlevel% neq 0 exit /b %errorlevel%



 
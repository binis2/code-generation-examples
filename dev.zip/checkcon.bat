@ECHO OFF
cls
cd code-generation-core
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-spring
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-annotation
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-test
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-validation
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-projection
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-jackson
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-spring-configuration
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-hibernate
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-redis
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
cd code-generation-plugin
call mvn -Dmaven.version.ignore="(?i).*-(alpha|beta|m|rc)([-.]?\d+)?" versions:display-dependency-updates versions:display-plugin-updates versions:display-property-updates
cd..
 